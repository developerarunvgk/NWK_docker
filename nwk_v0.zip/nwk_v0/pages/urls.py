"""nwk URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from . import views

from django.conf.urls import url
from django.contrib import admin
from django.contrib.auth import views as auth_views



urlpatterns = [
   # path('admin/', admin.site.urls),
   
   path('mydetails', views.myd, name='myd'),
		
 	    path('darabi', views.kaalakilla, name='nilam'),
		path('arun', views.arunvenu, name='nilam'),
		    path('nagpur', views.nagpur.as_view(), name='home'),
			path('', views.site_ip, name='home'),
			path('site_ip', views.site_ip, name='home1'),
			path('jip', views.site_ipj, name='site_ipj'),

			path('mailsend', views.ssend, name='home'),
			path('forma', views.forma, name='home'),
			path('uploada', views.model_form_upload, name='home'),
			path('share', views.share, name='home'),
			path('share1', views.share1, name='home'),
						path('sharegg1', views.sharegg1, name='home'),
						path('sharegg', views.sharegg, name='home'),

						path('ipuser', views.ip1234, name='home'),
						path('intra', views.intra, name='home'),

						url(r'^login/$', auth_views.LoginView, {'template_name': 'login.html'}, name='login'),

												path('rest1', views.rest1, name='home'),
												path('rest2', views.rest2, name='home'),
												path('rest3', views.rest3, name='home'),
												path('restg1', views.restg1.as_view(), name='home'),
]
