def welcome():
	s="Welcome to Peace and Silence";
	return s;