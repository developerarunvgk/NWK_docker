from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
from django.views.generic import TemplateView
from pages.models import ipdata
from pages.welcomemessage import welcome
from reportlab.pdfgen import canvas
from io import BytesIO
from django.conf import settings
from django.core.files.storage import FileSystemStorage
from django.core.mail import send_mail


import socket   




def kaalakilla(request):
    c = canvas.Canvas("hello.pdf")
    c.drawString(100,750,"Welcome to Reportlab!")
    c.save()
    print("PDF DONE");
    return HttpResponse('Rajini, Star!')
	

# Create your views here.

def arunvenu(request):
    # Create the HttpResponse object with the appropriate PDF headers.
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = 'inline;filename="somefilename.pdf"'

    buffer = BytesIO()

    # Create the PDF object, using the BytesIO object as its "file."
    p = canvas.Canvas(buffer)

    # Draw things on the PDF. Here's where the PDF generation happens.
    # See the ReportLab documentation for the full list of functionality.
    p.drawString(100, 100, "Hello world.")

    # Close the PDF object cleanly.
    p.showPage()
    p.save()

    # Get the value of the BytesIO buffer and write it to the response.
    pdf = buffer.getvalue()
    buffer.close()
    file = open("contract.pdf", "wb")
    file.write(pdf)
    response.write(pdf)
    return response 
def admin(request):
    return HttpResponse('I Belss you')
	
class nagpur(TemplateView):
    template_name = 'tamil.html'
	
	
def holidays(request):
    festival_list = ["Birthday", 'Holi', 'Diwali'];
    return render(request, 'hoidays.html',{"festival_list":"Birthday und Holi und Diwali"})

def site_ip(request):
	if request.method == "GET":
		request.session['name'] = 'Ludwik'

		#print('Ok');
		#host = socket.gethostbyname("www.python.com")
		#print(host);
		website=" ";
		website=request.GET.get('website');
		if website is None:
			website=""
			return render(request, 'web_ip.html',{"festival_list":"Birthday und Holi und Diwali"})
			
		print(website);
		hostname = socket.gethostname()   
		IPAddr = socket.gethostbyname(hostname)  
		web_ip="";
		try:
			
			web_ip=socket.gethostbyname(website)
			print(web_ip);
		except:
			print("Internal Error arun");
		
		print("Your Computer Name is:" + hostname)   
		print("Your Computer IP Address is:" + IPAddr)   
		dbsave1(web_ip,website);
		return render(request, 'web_ip.html',{"festival_list":"Birthday und Holi und Diwali","web_ip":web_ip,"ww":website})

	else:

		return render(request, 'web_ip.html',{"festival_list":"Birthday und Holi und Diwali"})


def dbsave1(ip,website):
	
	p = ipdata(ipsite=ip, ipcountry=website);
	print("Inserted");
	d=welcome();
	print(d);
	p.save()
	pass;
	
def ssend(request):
		print(request.session['name'])
		a=request.session['name']
		#send_mail(a, 'Everything will be fine', 'developerarunvgk', ['venuarunv@gmail.com']);
		a=request.POST['email'];
		file1=request.FILES['fileToUpload'];
		fs = FileSystemStorage()
		filename = fs.save(file1.name, file1)
		uploaded_file_url = fs.url(filename)

		print(a);
		print(file1);
		print("Mail send");
		return HttpResponse('file uploaded at '+uploaded_file_url)

def forma(request):
		return render(request, 'form1.html',{"festival_list":"Birthday und Holi und Diwali"})
